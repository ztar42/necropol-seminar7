# Семинар 7. Вайб-кодинг — практическое задание

Извлечение дат рождения и смерти из «Петербургского некрополя» (т. 1, СПб., 1912).
Код этапа «Даты» написан моделью Claude Sonnet по серии из пяти промтов.

## Что в архиве

| Файл | Что это |
|---|---|
| `reports/result.html`, `reports/result.docx` | Отчёт о выполнении задания (одинаковое содержание, HTML и Word) |
| `prompts/sonnet_prompts.md` | Серия промтов для этапа «Даты» |
| `code/dates_sonnet.py` | Код этапа «Даты», написанный Claude Sonnet по промтам (без правок) |
| `code/download.py`, `code/segment.py` | Этапы 0–1: скачивание источника, разбиение на статьи |
| `code/evaluate.py` | Сверка с ручной разметкой (точность и полнота) |
| `necropol_dates.py` | Всё решение одним файлом |
| `data/gold_dates.csv`, `data/holdout_dates.csv` | Ручная разметка: 60 статей для отладки и 40 отложенных |
| `output/dates_sonnet.csv` | Результат: даты и пометки для 13 620 статей |
| `output/dates_sonnet_review.csv` | 516 статей, помеченных для ручной проверки |
| `output/segment_report.txt` | Контроль этапа 1 |

Источник (`data/necropol_t1.txt`, 3 МБ) и промежуточный файл статей (`output/entries.csv`)
в архив не входят: они создаются командами ниже.

## Как воспроизвести

Python 3.10+, сторонние библиотеки не нужны. Команды выполняются из этой папки
(на Windows — `python` вместо `python3`).

Одной командой:

    python3 necropol_dates.py

Или по этапам:

    python3 code/download.py      # скачать OCR-текст с archive.org в data/
    python3 code/segment.py       # разбить на статьи -> output/entries.csv
    python3 code/dates_sonnet.py  # самопроверка (18 примеров) + даты + пометки
    python3 code/evaluate.py output/dates_sonnet.csv data/holdout_dates.csv   # отложенная выборка

Если скачивание не работает, источник можно сохранить вручную:
https://archive.org/download/peterburgskijnekropolt1ag60/peterburgskijnekropolt1ag60_djvu.txt
→ `data/necropol_t1.txt`.

Ожидаемый итог на отложенной выборке: дата смерти — точность 97 %, полнота 100 %;
дата рождения — 94 % и 100 %.
